<div>
    <div class="flex justify-between items-center mb-4">
        <input type="text" wire:model.live.debounce.300ms="search" placeholder="Search employee..." class="input input-bordered">
        <input type="date" wire:model.live="dateFilter" class="input input-bordered">
        <select wire:model.live="perPage" class="select select-bordered">
            <option>10</option>
            <option>25</option>
            <option>50</option>
        </select>
        <a href="<?php echo e(route('attendances.create')); ?>" class="btn btn-primary">Add Attendance</a>
    </div>

    <table class="mt-4 border-collapse border max-w-full w-full mb-4">
        <thead>
            <tr>
                <th class="border p-2">Employee</th>
                <th class="border p-2">Date</th>
                <th class="border p-2">Clock In</th>
                <th class="border p-2">Clock Out</th>
                <th class="border p-2">Status</th>
                <th class="border p-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border p-2"><?php echo e($attendance->employee->first_name .' '. $attendance->employee->last_name); ?></td>
                <td class="border p-2"><?php echo e($attendance->date->format('d M Y')); ?></td>
                <td class="border p-2"><?php echo e($attendance->clock_in?->format('H:i') ?? '-'); ?></td>
                <td class="border p-2"><?php echo e($attendance->clock_out?->format('H:i') ?? '-'); ?></td>
                <td class="border p-2">
                    <?php if (isset($component)) { $__componentOriginal4cc377eda9b63b796b6668ee7832d023 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4cc377eda9b63b796b6668ee7832d023 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::badge.index','data' => ['size' => 'sm','color' => match($attendance->status) {
                        'Present' => 'green',
                        'Absent' => 'red',
                        'Half Day' => 'orange'
                        },'inset' => 'top bottom']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','color' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(match($attendance->status) {
                        'Present' => 'green',
                        'Absent' => 'red',
                        'Half Day' => 'orange'
                        }),'inset' => 'top bottom']); ?>
                        <?php echo e($attendance->status); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $attributes = $__attributesOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__attributesOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4cc377eda9b63b796b6668ee7832d023)): ?>
<?php $component = $__componentOriginal4cc377eda9b63b796b6668ee7832d023; ?>
<?php unset($__componentOriginal4cc377eda9b63b796b6668ee7832d023); ?>
<?php endif; ?>
                </td>
                <td  class="border p-2 flex gap-2">
                    <a href="<?php echo e(route('attendances.edit', $attendance)); ?>" class="btn btn-sm btn-info">Edit</a>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('attendance.delete-attendance', ['attendance' => $attendance]);

$__html = app('livewire')->mount($__name, $__params, $attendance->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <?php echo e($attendances->links()); ?>

</div><?php /**PATH C:\wamp64\www\aniee\ems3\resources\views/livewire/attendance/attendance-table.blade.php ENDPATH**/ ?>