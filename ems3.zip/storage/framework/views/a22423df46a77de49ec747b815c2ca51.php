<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-slot="icon">
    <line x1="8" y1="6" x2="21" y2="6"></line>
    <line x1="8" y1="12" x2="21" y2="12"></line>
    <line x1="8" y1="18" x2="21" y2="18"></line>
    <circle cx="4" cy="6" r="1"></circle>
    <circle cx="4" cy="12" r="1"></circle>
    <circle cx="4" cy="18" r="1"></circle>
</svg><?php /**PATH C:\wamp64\www\aniee\ems3\resources\views/flux/icon/list.blade.php ENDPATH**/ ?>