
<legend <?php echo e($attributes->class('text-base font-medium text-zinc-800 dark:text-white')); ?> data-flux-legend>
    <?php echo e($slot); ?>

</legend>
<?php /**PATH C:\wamp64\www\aniee\ems3\vendor\livewire\flux\src/../stubs/resources/views/flux/legend.blade.php ENDPATH**/ ?>